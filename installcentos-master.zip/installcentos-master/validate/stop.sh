#!/bin/bash

source env.sh

terraform destroy -auto-approve